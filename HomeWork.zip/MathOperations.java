public class MathOperations {
    public static int sum(int a, int b) {
        return a + b;
    }

    public static int difference(int a, int b) {
        return a - b;
    }

    public static int product(int a, int b) {
        return a * b;
    }

    public static double division(int a, int b){
        return (double) a/b;
    }

}
